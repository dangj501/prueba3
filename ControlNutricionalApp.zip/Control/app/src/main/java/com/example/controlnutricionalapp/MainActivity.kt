package com.example.controlnutricionalapp

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.controlnutricionalapp.Modelo.NotasBD
import com.example.controlnutricionalapp.databinding.ActivityMainBinding
import com.example.controlnutricionalapp.poko.Nota

class MainActivity : AppCompatActivity() {

    private lateinit var binding : ActivityMainBinding
    private lateinit var modelo: NotasBD
    private var username = ""


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)
        modelo = NotasBD(this@MainActivity)

        username = intent.getStringExtra("username")!!
        binding.btnGuardarnota.setOnClickListener {
            if (validarNota()){
                val nuevaNota = Nota(0, binding.etTituloNota.text.toString(), binding.etCuerpoNota.text.toString(), username)
                agregarNota(nuevaNota)
            }
        }

        binding.btnEliminarnota.setOnClickListener {
            if(validarNota()){

            }
        }
    }


     override fun onResume(){
        super.onResume()
        cargarMisNotas()
    }

    fun cargarMisNotas(){
        val notas = modelo.seleccionarNotas()
        var informacion = ""
        for(nota in notas){
            informacion += "ID nota: ${nota.idNota}, Titulo: ${nota.titulo}, ID usuario: ${nota.idUsuario}\n\n"
        }
        binding.notasGuardadas.setText(informacion)

    }

    fun agregarNota(nota: Nota){
        val resultadoInsercion = modelo.insertarNota(nota)
        var mensaje = ""
        if(resultadoInsercion > 0){
            mensaje = "Nota guardada correctamente"
            binding.etTituloNota.setText("")
            binding.etCuerpoNota.setText("")
            cargarMisNotas()
        }else {
            mensaje = "Hubo un error al guardar la nota, intentelo nuevamente"
        }
        Toast.makeText(this@MainActivity, mensaje, Toast.LENGTH_LONG).show()
    }

    fun validarNota():Boolean{
        var valido = true
        if(binding.etTituloNota.text.isEmpty()){
            binding.etTituloNota.setError("Titulo obliatorio")
            valido = false
        }

        if(binding.etCuerpoNota.text.isEmpty()){
            binding.etCuerpoNota.setError("Cuerpo obligatorio")
            valido = false
        }

        if(binding.txId.text.isEmpty()){
            binding.txId.setError("Id obligatorio")
            valido = false
        }
        return valido
    }

    fun actualizarNota(){
        
    }

    fun operacionEliminarNota(idNota: Long): Int{
        return modelo.eliminarNota(idNota)
    }

}