package com.example.controlnutricionalapp

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.controlnutricionalapp.databinding.ActivityLoginBinding
import com.example.controlnutricionalapp.utilidades.Constantes
import com.example.controlnutricionalapp.utilidades.ConstantesEstatico

class LoginActivity : AppCompatActivity() {
    private lateinit var binding:ActivityLoginBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate (layoutInflater)
        val view = binding.root
        setContentView(view)
        cargarCredenciales()

        binding.btnIngreso.setOnClickListener {
            verificarCredenciales()
        }

    }

    fun cargarCredenciales(){
        val archivoPreferenciasDefault = getPreferences(Context.MODE_PRIVATE)
        binding.etCorreo.setText(archivoPreferenciasDefault.getString("correo", ""))
        binding.etContrsenia.setText(archivoPreferenciasDefault.getString("password", ""))

        if(archivoPreferenciasDefault.getBoolean("guardar", false)){
            binding.checkbox.isChecked = true
        }

    }

    fun guardarCredenciales(correo: String, password: String, validar: Boolean){
        val archivoPreferenciasDefault = getPreferences(Context.MODE_PRIVATE)
        val preferenciaUno = getSharedPreferences("cookies", Context.MODE_PRIVATE)
        val archivoEdit = archivoPreferenciasDefault.edit()
        archivoEdit.putString("correo", correo)
        archivoEdit.putString("password", password)
        archivoEdit.putBoolean("guardar", validar)
        archivoEdit.apply()

        /*with(archivoPreferenciasDefault.edit()){
            putString("correo", correo)
            putString("password", password)
            putBoolean("guardar", validar)
            apply()
        }*/

    }

    fun verificarCredenciales(){
        val correo = binding.etCorreo.text.toString()
        val password = binding.etContrsenia.text.toString()
        if(correo.equals(Constantes.USERNAME1) && password.equals(Constantes.PASSWORD1) ||
            correo.equals(ConstantesEstatico.USERNAME2) && password.equals(ConstantesEstatico.PASSWORD2)){
            if(binding.checkbox.isChecked){
                guardarCredenciales(correo, password, true)
            }else{
                guardarCredenciales("", "", false)
            }
            mostrarToast("Bienvenido a la aplicacion...")
            irPantallaPrincipa(correo)
        }else {
            mostrarToast("Usuario incorrecto")
        }
    }

    fun mostrarToast(mensaje: String){
        Toast.makeText(this@LoginActivity, mensaje, Toast.LENGTH_SHORT).show()
    }

    fun irPantallaPrincipa(username : String){
        val intent = Intent (this@LoginActivity, MainActivity::class.java)
        intent.putExtra("username", username)
        startActivity(intent)
    }

}