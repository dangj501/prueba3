package com.example.controlnutricionalapp.utilidades

class ConstantesEstatico {

    companion object {
        const val USERNAME2 = "invitado@gmail.com"
        const val  PASSWORD2 = "qwerty"
    }
}