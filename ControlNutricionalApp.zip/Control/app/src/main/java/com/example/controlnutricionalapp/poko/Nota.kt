package com.example.controlnutricionalapp.poko

data class Nota(
    val idNota: Long,
    val titulo: String,
    val contenido: String,
    val idUsuario: String
)
