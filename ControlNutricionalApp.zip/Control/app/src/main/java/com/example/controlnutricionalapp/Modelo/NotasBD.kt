package com.example.controlnutricionalapp.Modelo

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import androidx.core.content.contentValuesOf
import com.example.controlnutricionalapp.poko.Nota

class NotasBD (contexto: Context) : SQLiteOpenHelper(contexto, NOMBRE_BD, null, VERSION_BD) {


    companion object{
        private const val NOMBRE_BD = "notas.db"
        private const val NOMBRE_TABLA = "notas"
        private const val COL_ID = "idNombre"
        private const val COL_TITULO = "titulo"
        private const val COL_CONTENIDO = "contenido"
        private const val COL_ID_USUARIO = "idUsuario"
        private const val VERSION_BD = 1
    }

    //Crear
    override fun onCreate(p0: SQLiteDatabase?) {
        val CREATE_TABLE_NOTAS = ("CREATE TABLE ${NOMBRE_TABLA} ($COL_ID INTEGER PRIMARY KEY AUTOINCREMENT, $COL_TITULO TEXT, $COL_CONTENIDO TEXT, $COL_ID_USUARIO TEXT)")

        p0!!.execSQL(CREATE_TABLE_NOTAS)
    }

    //Actualiza. aqui se lleva back-up
    override fun onUpgrade(p0: SQLiteDatabase?, p1: Int, p2: Int) {
        // Para actualizar la version de la BD
    }

    //IMPLEMNTAR LOS METODOS DE ACCION SELECT, INSERT

    fun insertarNota(nota: Nota): Long {
        val db = writableDatabase
        val valoresInsert = ContentValues()
        valoresInsert.put(COL_TITULO, nota.titulo)
        valoresInsert.put(COL_CONTENIDO, nota.contenido)
        valoresInsert.put(COL_ID_USUARIO, nota.idUsuario)
        val filasAfectadas = db.insert(NOMBRE_TABLA, null, valoresInsert)
        db.close()
        return  filasAfectadas
    }

    @SuppressLint("Range")
    fun seleccionarNotas() : List<Nota>{
        val misNotas = mutableListOf<Nota>()
        val db = readableDatabase
        val resultadoConsulta : Cursor = db.query(NOMBRE_TABLA, null, null, null, null, null, null)
        if(resultadoConsulta != null){
            while (resultadoConsulta.moveToNext()){
                val idNota = resultadoConsulta.getLong(resultadoConsulta.getColumnIndex(COL_ID))
                val titulo = resultadoConsulta.getString(resultadoConsulta.getColumnIndex(COL_TITULO))
                val contenido = resultadoConsulta.getString(resultadoConsulta.getColumnIndex(COL_CONTENIDO))
                val idUsuario = resultadoConsulta.getString(resultadoConsulta.getColumnIndex(COL_ID_USUARIO))
                val nota = Nota(idNota, titulo, contenido, idUsuario)
                misNotas.add(nota)
            }
            resultadoConsulta.close()
        }
        db.close()
        return misNotas
    }

    fun actualizarNota(nota: Nota): Int{
        val db = writableDatabase
        val valoresUpdate = contentValuesOf().apply {
            put(COL_TITULO, nota.titulo)
            put(COL_CONTENIDO, nota.contenido)
        }
        val filasAfectadas = db.update(NOMBRE_TABLA, valoresUpdate, "$COL_ID = ?", arrayOf(nota.idNota.toString()))
        db.close()
        return filasAfectadas
    }

    fun eliminarNota(idNota : Long): Int{
        val db = writableDatabase
        val filasAfectadas = db.delete(NOMBRE_TABLA, "$COL_ID = ?", arrayOf(idNota.toString()))
        db.close()
        return filasAfectadas
    }

}