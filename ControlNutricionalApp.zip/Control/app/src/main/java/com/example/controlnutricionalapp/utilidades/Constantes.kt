package com.example.controlnutricionalapp.utilidades

object Constantes {
    val USERNAME1 : String = "admin@gmail.com"
    val PASSWORD1 : String = "12345"
}